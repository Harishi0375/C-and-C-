/*
  CH-230-A
  a12_p6.cpp
  Harishi Velavan
  hvelavan@jacobs-university.de
*/

#include <iostream>
using namespace std;
#include "Area.h"
#include "Circle.h"
#include "Ring.h"
#include "Rectangle.h"
#include "Square.h"

const int num_obj = 7;

/*               Area
                  ^         
				/    \
			   /      \
		 Circle  	   Rectangle
		  ^               ^
		  |               |
		Ring            Square
*/

int main() {
    Area *list[num_obj];
    int index = 0;
    double sum_area = 0.0;
    double sum_perimeter = 0.0;

    cout << "Creating Ring: ";
    Ring blue_ring("BLUE", 5, 2);
    cout << "Creating Circle: ";
    Circle yellow_circle("YELLOW", 7);
    cout << "Creating Rectangle: ";
    Rectangle green_rectangle("GREEN", 5, 6);
    cout << "Creating Circle: ";
    Circle red_circle("RED", 8);
    cout << "Creating Rectangle: ";
    Rectangle black_rectangle("BLACK", 10, 20);
    cout << "Creating Ring: ";
    Ring violet_ring("VIOLET", 100, 5);
	Square pink_square("PINK",7);

    list[0] = &blue_ring;
    list[1] = &yellow_circle;
    list[2] = &green_rectangle;
    list[3] = &red_circle;
    list[4] = &black_rectangle;
    list[5] = &violet_ring;
	list[6] = &pink_square;

    while (index < num_obj) {
        (list[index])->getColor();
        double area = list[index]->calcArea();
        double perimeter = list[index]->calcPer(); // Assuming calcPer is implemented in all classes

        cout << "Area: " << area << " units, Perimeter: " << perimeter << " units" << endl;

        sum_area += area;
        sum_perimeter += perimeter;

        index++;
    }

    cout << "\nThe total area is " << sum_area << " units" << endl;
    cout << "The total perimeter is " << sum_perimeter << " units" << endl;

    return 0;
}

